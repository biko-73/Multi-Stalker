from skin import loadSkin
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, fileExists
from gettext import gettext, dgettext, bindtextdomain

__version__ = 1.1

PluginLanguageDomain = "MultiStalkerPro"
PluginLanguagePath = f"Extensions/{PluginLanguageDomain}/locale"

def loadPluginSkin():
    skin = resolveFilename(SCOPE_PLUGINS, "Extensions/MultiStalkerPro/assets/skins/skin.xml")
    print("[MultiStalkerPro] load skin", skin)
    if fileExists(skin):
        loadSkin(skin)

def localeInit():
    bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))

def _(txt):
    t = dgettext(PluginLanguageDomain, txt)
    if t == txt:
        t = gettext(txt)
    return t

localeInit()
language.addCallback(localeInit)